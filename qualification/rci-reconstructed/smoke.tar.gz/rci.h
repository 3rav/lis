#ifndef LIS_RCI_RECONSTRUCTED_H
#define LIS_RCI_RECONSTRUCTED_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Independent reconstructed API; not the original LIS Generic RCI ABI. */
typedef struct rci_context rci_context;
typedef enum { RCI_CG=1, RCI_BICGSTAB, RCI_GMRES, RCI_FGMRES } rci_method;
typedef enum { RCI_DONE=0, RCI_MATVEC=1, RCI_PRECON=2, RCI_MAXITER=-1,
 RCI_BREAKDOWN=-2, RCI_BADARG=-3, RCI_CALLBACK=-4, RCI_NONFINITE=-5,
 RCI_STATE=-6 } rci_status;
typedef struct { size_t n, maxiter, restart; double rtol, atol; rci_method method; } rci_options;
typedef struct { const double *in; double *out; size_t n; } rci_request;
typedef struct { size_t iterations, matvecs, precons; double residual; int status, callback_code; } rci_info;
rci_context *rci_create(const rci_options *options);
void rci_destroy(rci_context *c);
/* b and x0 are copied. x0 may be NULL (zero guess). Cannot start while active. */
int rci_start(rci_context *c,const double *b,const double *x0,rci_request *q);
/* Complete previous request; callback_code=0 on success. Request buffers valid until next call. */
int rci_advance(rci_context *c,int callback_code,rci_request *q);
const double *rci_solution(const rci_context *c);
int rci_get_info(const rci_context *c,rci_info *info);
#ifdef __cplusplus
}
#endif
#endif
