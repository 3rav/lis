#ifndef RCI_LIS_BRIDGE_H
#define RCI_LIS_BRIDGE_H
#include "rci.h"
#include <lis.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Serial real-double LIS only. A is borrowed and must remain valid/unchanged during solve. */
typedef struct rci_lis_bridge rci_lis_bridge;
/* jacobi=0 identity, jacobi=1 diagonal inverse; CG requires positive diagonal. */
int rci_lis_create(LIS_MATRIX A,const rci_options *opt,int jacobi,rci_lis_bridge **out);
void rci_lis_destroy(rci_lis_bridge *p);
/* b/x are arrays of opt.n doubles. x initial guess and result (on successful solve only). */
int rci_lis_solve(rci_lis_bridge *p,const double *b,double *x,rci_info *info);
#ifdef __cplusplus
}
#endif
#endif
