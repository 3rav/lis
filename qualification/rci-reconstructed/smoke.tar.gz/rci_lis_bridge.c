#include "rci_lis_bridge.h"
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#if defined(USE_MPI)
#error Bridge is qualified only for non-MPI LIS
#endif
_Static_assert(_Generic((LIS_SCALAR)0,double:1,default:0),"real-double LIS only");
_Static_assert(sizeof(LIS_INT)<=sizeof(int64_t),"unsupported LIS_INT");
struct rci_lis_bridge { LIS_MATRIX A; LIS_VECTOR u,v; rci_context *ctx; LIS_INT n; double *buf,*diag; int jacobi,cg; };
static int lis_error(LIS_INT e){int64_t k=(int64_t)e;return (k>=INT_MIN&&k<=INT_MAX&&k!=0)?(int)k:1;}
void rci_lis_destroy(rci_lis_bridge*p){if(!p)return;if(p->v)lis_vector_destroy(p->v);if(p->u)lis_vector_destroy(p->u);rci_destroy(p->ctx);free(p->buf);free(p->diag);free(p);}
int rci_lis_create(LIS_MATRIX A,const rci_options *o,int jacobi,rci_lis_bridge **out){
 if(!out)return RCI_BADARG;
 *out=NULL;
 if(!A||!o||!o->n||o->n>SIZE_MAX/sizeof(double)||(jacobi!=0&&jacobi!=1))return RCI_BADARG;
 LIS_INT n=0,g=0;
 if(lis_matrix_get_size(A,&n,&g)!=0||n<=0||n!=g||(uintmax_t)n!=(uintmax_t)o->n)return RCI_BADARG;
 rci_lis_bridge*p=calloc(1,sizeof(*p));if(!p)return RCI_BADARG;
 p->A=A;p->n=n;p->jacobi=jacobi;p->cg=(o->method==RCI_CG);
 p->ctx=rci_create(o);p->buf=malloc(o->n*sizeof(double));if(jacobi)p->diag=malloc(o->n*sizeof(double));
 if(!p->ctx||!p->buf||(jacobi&&!p->diag)){rci_lis_destroy(p);return RCI_BADARG;}
 if(lis_vector_duplicate(A,&p->u)!=0||lis_vector_duplicate(A,&p->v)!=0){rci_lis_destroy(p);return RCI_CALLBACK;}
 *out=p;return 0;
}
int rci_lis_solve(rci_lis_bridge*p,const double*b,double*x,rci_info*info){
 if(!p||!b||!x||!info)return RCI_BADARG;
 *info=(rci_info){.residual=NAN,.status=RCI_BADARG};
 LIS_INT n=p->n,e=0,local=0,global=0;
 if(lis_matrix_get_size(p->A,&local,&global)!=0||local!=n||global!=n)return RCI_BADARG;
 if(p->jacobi){
  e=lis_matrix_get_diagonal(p->A,p->v);if(!e)e=lis_vector_get_values(p->v,0,n,p->diag);
  if(e){info->status=RCI_CALLBACK;info->callback_code=lis_error(e);return RCI_CALLBACK;}
  for(LIS_INT i=0;i<n;i++)if(!isfinite(p->diag[i])||p->diag[i]==0||(p->cg&&p->diag[i]<0))return RCI_BADARG;
 }
 rci_request q;int s=rci_start(p->ctx,b,x,&q);
 while(s==RCI_MATVEC||s==RCI_PRECON){
  e=0;
  if(s==RCI_MATVEC){memcpy(p->buf,q.in,q.n*sizeof(double));
   e=lis_vector_set_values2(LIS_INS_VALUE,0,n,p->buf,p->u);
   if(!e)e=lis_matvec(p->A,p->u,p->v);
   if(!e)e=lis_vector_get_values(p->v,0,n,q.out);
  }else for(size_t i=0;i<q.n;i++)q.out[i]=p->jacobi?q.in[i]/p->diag[i]:q.in[i];
  s=rci_advance(p->ctx,e?lis_error(e):0,&q);
 }
 rci_get_info(p->ctx,info);if(s==RCI_DONE)memcpy(x,rci_solution(p->ctx),(size_t)n*sizeof(double));return s;
}
